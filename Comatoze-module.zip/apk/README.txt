Folder ini hanya berisi comatoze.apk (aplikasi pendamping Comatoze).
Fitur overlay FPS (UltraFPS) sudah dihapus dari modul.
