SKIPUNZIP=0
ui_print "- Memasang Comatoze"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/bin/ultrapower 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755

# Disable Thermal (brutal): daftar file thermal bawaan perangkat yang akan ditimpa file kosong saat THERMAL=off (lihat post-fs-data.sh)
ui_print "- Memindai file konfigurasi thermal perangkat"
find /system/vendor/ -name '*thermal*.conf' -type f 2>/dev/null | while read -r nama; do
  echo "${nama#/}" >> $MODPATH/thermal_overlay.list
done
sort -u $MODPATH/thermal_overlay.list > $MODPATH/thermal_overlay.tmp && mv $MODPATH/thermal_overlay.tmp $MODPATH/thermal_overlay.list
ui_print "- Selesai. Buka WebUI modul atau jalankan 'su -c ultrapower status'"

# --- COMATOZE
if [ -f $MODPATH/apk/comatoze.apk ]; then
  ui_print "- Memasang aplikasi Comatoze"
  cp $MODPATH/apk/comatoze.apk /data/local/tmp/comatoze.apk && chmod 644 /data/local/tmp/comatoze.apk
  if pm install -r /data/local/tmp/comatoze.apk >/dev/null 2>&1; then
    ui_print "- Comatoze terpasang"
  else
    ui_print "! Gagal memasang Comatoze (dicoba lagi saat boot)"
  fi
  rm -f /data/local/tmp/comatoze.apk
else
  ui_print "- APK Comatoze tidak disertakan (install manual)"
fi